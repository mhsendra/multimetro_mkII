#ifndef ADC_MANAGER_H
#define ADC_MANAGER_H

#include <Arduino.h>
#include <stdint.h>
#include <stdbool.h>

/* =========================
 * Tipos públicos
 * ========================= */

typedef enum
{
    ADC_REF_AVCC,
    ADC_REF_INTERNAL_1V1,
    ADC_REF_EXTERNAL
} adc_reference_t;

typedef enum
{
    ADC_CH_0,
    ADC_CH_1,
    ADC_CH_2,
    ADC_CH_3,
    ADC_CH_4,
    ADC_CH_5,
    ADC_CH_6,
    ADC_CH_7
} adc_channel_t;

/* Rangos lógicos del multímetro */
typedef enum
{
    RANGE_NONE = 0,

    // DC
    RANGE_DC_200mV,
    RANGE_DC_2V,
    RANGE_DC_20V,
    RANGE_DC_200V,

    // AC
    RANGE_AC_2V,
    RANGE_AC_20V,
    RANGE_AC_200V,

    // OHM
    RANGE_OHM_100,
    RANGE_OHM_10K,
    RANGE_OHM_1M,

    // Intensidad
    RANGE_CURR_20mA,
    RANGE_CURR_200mA,
    RANGE_CURR_16A,

    // Transistores
    RANGE_TRANSISTOR,

    RANGE_MAX
} adc_range_id_t;

typedef enum
{
    ADC_SPS_8,
    ADC_SPS_16,
    ADC_SPS_32,
    ADC_SPS_64,
    ADC_SPS_128,
    ADC_SPS_250,
    ADC_SPS_475,
    ADC_SPS_860
} adc_sps_t;

/* =========================
 * API pública
 * ========================= */

void adc_manager_init(void);

/* Selecciona rango completo:
 * - pines SEL
 * - referencia
 * - canal ADC
 * Invalida lecturas anteriores
 */
void adc_manager_select(adc_range_id_t range);

/* Lectura no bloqueante
 * Devuelve true solo cuando el valor es estable
 */
bool adc_manager_read(uint16_t *value);

/* Lectura bloqueante (uso puntual) */
uint16_t adc_manager_read_blocking(void);

/* Utilidades */
adc_range_id_t adc_manager_current_range(void);

/* Velocidad de muestreo de ADS1115 */
void adc_manager_set_sps(adc_sps_t sps);

float adc_manager_raw_to_voltage(uint16_t raw);

extern uint16_t ads_gain;

#endif
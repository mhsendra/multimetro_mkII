/*#include "mode_current.h"
#include "adcmanager.h"
#include "lcd_ui.h"
#include "globals.h"
#include "auto_Hold.h"
#include "backlight.h"
#include "AutoOff.h"

// Ajusta esto si tu ADC no usa AVCC=5V
static constexpr float ADC_VREF = 5.0f;
static constexpr float ADC_LSB = ADC_VREF / 1023.0f;

// =====================================================
// CORRIENTE mA (shunt 0,1 Ω + LM358)
// =====================================================
float measureCurrent_mA()
{
    adc_manager_select(RANGE_CURR_20mA); // mapea este rango en adcmanager.cpp
    uint16_t raw = adc_manager_read_blocking();

    float v = raw * ADC_LSB;           // V a la salida del opamp
    v -= cal.curr_shunt_offset;        // offset calibrado
    float i = v * cal.curr_shunt_gain; // A

    return i;
}

// =====================================================
// CORRIENTE 5A (shunt 0,033 Ω + LM358)
// =====================================================
float measureCurrent_5A()
{
    adc_manager_select(RANGE_CURR_200mA); // segundo rango de shunt
    uint16_t raw = adc_manager_read_blocking();

    float v = raw * ADC_LSB;
    v -= cal.curr_shunt_offset;
    float i = v * cal.curr_shunt_gain; // misma ganancia, distinto shunt ya absorbido en cal

    return i;
}

// =====================================================
// CORRIENTE 16A (ACS712‑20A)
// =====================================================
float measureCurrent_16A()
{
    // Añade este rango en adc_range_id_t y en adcmanager.cpp
    adc_manager_select(RANGE_CURR_16A);
    uint16_t raw = adc_manager_read_blocking();

    float v = raw * ADC_LSB;
    v -= cal.acs_offset;
    float i = v / cal.acs_sens; // A (cal.acs_sens ≈ 0.1 V/A para ACS712‑20A)

    return i;
}

// =====================================================
// DISPATCHER CALIBRADO
// =====================================================
float measureCURRENT_calibrated()
{
    switch (currentRange)
    {
    case CURR_RANGE_mA:
        return measureCurrent_mA();
    case CURR_RANGE_5A:
        return measureCurrent_5A();
    case CURR_RANGE_16A:
        return measureCurrent_16A();
    }
    return NAN;
}

// =====================================================
// PANTALLA
// =====================================================
void showCURRENT()
{
    static float If = NAN;

    float i = measureCURRENT_calibrated();

    if (!isinf(i) && !isnan(i))
    {
        backlight_activity();
        autoOff_activity();
    }

    if (autoHold_update(i))
        i = autoHold_getHeldValue();

    lcd_ui_clear();

    if (isinf(i))
    {
        lcd_ui_print("I: OVL");
        return;
    }

    If = applyEMA(i, If, 0.20f);

    if (currentRange == CURR_RANGE_mA)
    {
        lcd_ui_print("I: ");
        lcd_ui_printFloat(If * 1000.0f, 1);
        lcd_ui_print(" mA");
    }
    else
    {
        lcd_ui_print("I: ");
        lcd_ui_printFloat(If, 3);
        lcd_ui_print(" A");
    }
}

// =====================================================
// MODO COMPLETO
// =====================================================
void measureCURRENT()
{
    showCURRENT();
}*/

#include "mode_current.h"
#include "adcmanager.h"
#include "lcd_ui.h"
#include "globals.h"
#include "auto_Hold.h"
#include "backlight.h"
#include "AutoOff.h"
#include "range_control.h"

// =====================================================
// CORRIENTE mA y 5A (shunt + LM358 → ADS1115 canal shunt)
// =====================================================
float measureCurrent_Shunt_RAW()
{
    // Seleccionar rango ADC según rango lógico
    if (currentRange == CURR_RANGE_mA)
    {
        adc_manager_select(RANGE_CURR_20mA);
    }
    else // CURR_RANGE_5A
    {
        adc_manager_select(RANGE_CURR_200mA);
    }

    // Leer RAW del ADS1115
    uint16_t raw = adc_manager_read_blocking();

    // Convertir a voltios reales
    float v = adc_manager_raw_to_voltage(raw);

    // Protección por saturación
    if (v > 4.95f)
        return INFINITY;

    // Aplicar offset del amplificador
    v -= cal.curr_shunt_offset;

    // Convertir a corriente (A)
    float i = v * cal.curr_shunt_gain;

    return i;
}

// =====================================================
// CORRIENTE 16A (ACS712 → ADS1115 canal ACS)
// =====================================================
float measureCurrent_ACS_RAW()
{
    // Seleccionar rango ADC para ACS712
    adc_manager_select(RANGE_CURR_16A);

    // Leer RAW del ADS1115
    uint16_t raw = adc_manager_read_blocking();

    // Convertir a voltios reales
    float v = adc_manager_raw_to_voltage(raw);

    // Protección por saturación
    if (v > 4.95f)
        return INFINITY;

    // Aplicar offset calibrado
    v -= cal.acs_offset;

    // Convertir a corriente (A)
    float i = v / cal.acs_sens;

    return i;
}

// =====================================================
// DISPATCHER RAW
// =====================================================
float measureCURRENT_RAW()
{
    // Permite liberar 3 pines RNGx para uso fuera MODE OHM
    rng_release_for_gpio();

    switch (currentRange)
    {
    case CURR_RANGE_mA:
    case CURR_RANGE_5A:
        return measureCurrent_Shunt_RAW();

    case CURR_RANGE_16A:
        return measureCurrent_ACS_RAW();
    }

    return NAN;
}

// =====================================================
// CALIBRADO (wrapper limpio)
// =====================================================
float measureCURRENT_calibrated()
{
    float i = measureCURRENT_RAW();
    // Las funciones RAW ya aplican calibración (offset/gain/sens),
    // así que aquí no hace falta tocar nada más.
    return i;
}

// =====================================================
// PANTALLA (con filtro EMA, backlight, autoOff, autoHold)
// =====================================================
void showCURRENT()
{
    static float If = -1.0f;

    float i = measureCURRENT_calibrated();

    // Actividad si la lectura es válida
    if (!isinf(i) && !isnan(i))
    {
        backlight_activity();
        autoOff_activity();
    }

    if (autoHold_update(i))
        i = autoHold_getHeldValue();

    lcd_ui_clear();

    if (isinf(i))
    {
        lcd_ui_print("I: OVL");
        return;
    }

    // Filtro EMA para suavizar ruido
    If = applyEMA(i, If, 0.20f);

    if (currentRange == CURR_RANGE_mA)
    {
        lcd_ui_print("I: ");
        lcd_ui_printFloat(If * 1000.0f, 1);
        lcd_ui_print(" mA");
    }
    else
    {
        lcd_ui_print("I: ");
        lcd_ui_printFloat(If, 3);
        lcd_ui_print(" A");
    }
}

// =====================================================
// MODO COMPLETO
// =====================================================
void measureCURRENT()
{
    // Velocidad del ADS1115 adecuada para corriente
    adc_manager_set_sps(ADC_SPS_475);

    showCURRENT();
}
#ifndef MODE_MOSFET_H
#define MODE_MOSFET_H

#include <Arduino.h>
#include "config.h"

// Prototipos
float measureMosfet();
void showMosfet();

#endif
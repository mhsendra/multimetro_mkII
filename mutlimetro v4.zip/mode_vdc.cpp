#warning "Compilando mode_vdc.cpp"
#include "mode_vdc.h"
#include "adcmanager.h"
#include "globals.h"
#include "lcd_ui.h"
#include "config.h"
#include "auto_Hold.h"
#include "mode_current.h"
#include "backlight.h"
#include "AutoOff.h"
#include "auto_Hold.h"
#include "range_control.h"

// =====================================================
// AUTO-RANGO VISUAL (mV / V) con histéresis
// =====================================================
bool use_millivolts(float v)
{
    static bool in_mV = false;

    if (v < 0.95f)
        in_mV = true;
    if (v > 1.05f)
        in_mV = false;

    return in_mV;
}

// =====================================================
// VDC — RAW usando ADC Manager
// =====================================================
float measureVDC_raw()
{
    uint16_t raw = adc_manager_read_blocking();

    // Saturación del ADC → infinito
    if (raw >= 1020)
        return INFINITY;

    // Escalado según rango actual
    adc_range_id_t r = adc_manager_current_range();

    float scale = 1.0f;

    switch (r)
    {
    case RANGE_DC_200mV:
        scale = 0.0011f;
        break;
    case RANGE_DC_2V:
        scale = 0.011f;
        break;
    case RANGE_DC_20V:
        scale = 0.110f;
        break;
    case RANGE_DC_200V:
        scale = 1.10f;
        break;
    default:
        return NAN;
    }

    // Conversión ADC → voltios
    float v_adc = raw * (5.0f / 1023.0f);

    return v_adc * scale;
}

float measureVDC_calibrated()
{
    float v = measureVDC_raw();
    if (isinf(v))
        return v;

    return v * cal.vdc;
}

// =====================================================
// VDC RELATIVO
// =====================================================
static float vdc_reference = NAN;

float measureVDC_Relative()
{
    float v = measureVDC_calibrated();

    if (isnan(vdc_reference))
        vdc_reference = v;

    return v - vdc_reference;
}

// =====================================================
// POWER (W)
// =====================================================
float measurePower()
{
    float v = measureVDC_calibrated();
    float i = measureCURRENT_calibrated();

    if (isinf(v))
        return INFINITY;

    return v * i;
}

// =====================================================
// ENERGY (Wh)
// =====================================================
static unsigned long lastEnergyUpdate = 0;
static float energy_Wh = 0;

float measureEnergy()
{
    unsigned long now = millis();

    if (lastEnergyUpdate == 0)
    {
        lastEnergyUpdate = now;
        return energy_Wh;
    }

    float dt_h = (now - lastEnergyUpdate) / 3600000.0f;

    float p = measurePower();
    if (!isinf(p))
        energy_Wh += p * dt_h;

    lastEnergyUpdate = now;
    return energy_Wh;
}

// =====================================================
// PANTALLAS
// =====================================================
void showVDC()
{
    float v = measureVDC_calibrated();
    if (autoHold_update(v))
        v = autoHold_getHeldValue();

    lcd_ui_clear();

    if (isinf(v))
    {
        lcd_ui_print("VDC: OVL");
        return;
    }

    if (use_millivolts(v))
    {
        lcd_ui_print("VDC: ");
        lcd_ui_printFloat(v * 1000.0f, 1);
        lcd_ui_print(" mV");
    }
    else
    {
        lcd_ui_print("VDC: ");
        lcd_ui_printFloat(v, 3);
        lcd_ui_print(" V");
    }
}

void showVDC_Relative()
{
    float v = measureVDC_Relative();
    lcd_ui_clear();

    if (isinf(v))
    {
        lcd_ui_print("REL: OVL");
        return;
    }

    if (use_millivolts(fabs(v)))
    {
        lcd_ui_print("REL: ");
        lcd_ui_printFloat(v * 1000.0f, 1);
        lcd_ui_print(" mV");
    }
    else
    {
        lcd_ui_print("REL: ");
        lcd_ui_printFloat(v, 3);
        lcd_ui_print(" V");
    }
}

void showPower()
{
    float p = measurePower();
    lcd_ui_clear();

    if (isinf(p))
    {
        lcd_ui_print("P: OVL");
        return;
    }

    lcd_ui_print("P: ");
    lcd_ui_printFloat(p, 2);
    lcd_ui_print(" W");
}

void showEnergy()
{
    float e = measureEnergy();
    lcd_ui_clear();

    lcd_ui_print("E: ");
    lcd_ui_printFloat(e, 3);
    lcd_ui_print(" Wh");
}

// =====================================================
// MODO COMPLETO
// =====================================================
void measureVDC_MODE()
{
    // Permite liberar 3 pines RNGx para uso fuera MODE OHM
    rng_release_for_gpio();

    // Actividad del usuario (mantiene luz y evita auto‑apagado)
    backlight_activity();
    autoOff_activity();

    // Selección de rango inicial
    adc_manager_select(RANGE_DC_20V);

    switch (vdcSubMode)
    {
    case VDC_MAIN:
        showVDC(); // autoHold ya está dentro
        break;

    case VDC_REL:
        showVDC_Relative();
        break;

    case VDC_POWER:
        showPower();
        break;

    case VDC_ENERGY:
        showEnergy();
        break;

    case VDC_CURRENT_EST:
        lcd_ui_clear();
        lcd_ui_print("I est: ");
        lcd_ui_printFloat(measureCURRENT_calibrated() * 1000.0f, 1);
        lcd_ui_print(" mA");
        break;
    }
}
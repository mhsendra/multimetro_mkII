#ifndef CABLE_TEST_H
#define CABLE_TEST_H

extern bool cableOK;
extern unsigned long lastBreak;

void cableTest_update();

#endif
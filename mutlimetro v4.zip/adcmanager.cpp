#include "adcmanager.h"
#include <Arduino.h>

// Si tienes este struct en otro sitio:
#include "globals.h"
extern Pins pin;

/* =========================
 * Configuración interna
 * ========================= */

typedef struct
{
    adc_range_id_t id;
    adc_channel_t ch;
    adc_reference_t ref;
} adc_range_cfg_t;

// Mapa de rangos lógicos → canal ADC + referencia
// Ajusta los canales si tu hardware usa otros
static const adc_range_cfg_t adc_ranges[] =
    {
        // Rango nulo
        {RANGE_NONE, ADC_CH_0, ADC_REF_AVCC},

        // VDC (asumimos entrada principal en A0 / ADC_CH_0)
        {RANGE_DC_200mV, ADC_CH_0, ADC_REF_AVCC},
        {RANGE_DC_2V, ADC_CH_0, ADC_REF_AVCC},
        {RANGE_DC_20V, ADC_CH_0, ADC_REF_AVCC},
        {RANGE_DC_200V, ADC_CH_0, ADC_REF_AVCC},

        // Corriente mA / 5A → LM358 → TP1 = A2 = ADC_CH_2
        {RANGE_CURR_20mA, ADC_CH_2, ADC_REF_AVCC},
        {RANGE_CURR_200mA, ADC_CH_2, ADC_REF_AVCC},

        // Corriente 16A → ACS712 → ADC_ACS = A3 = ADC_CH_3
        {RANGE_CURR_16A, ADC_CH_3, ADC_REF_AVCC},

        // Ohmios (asumimos misma entrada que V, A0)
        {RANGE_OHM_100, ADC_CH_0, ADC_REF_AVCC},
        {RANGE_OHM_10K, ADC_CH_0, ADC_REF_AVCC},
        {RANGE_OHM_1M, ADC_CH_0, ADC_REF_AVCC},

        // Transistor (usa el mismo nodo que OHM/DIODO → ADC_CH_0)
        {RANGE_TRANSISTOR, ADC_CH_0, ADC_REF_AVCC},

};

static adc_range_id_t current_range = RANGE_NONE;
static uint8_t current_analog_pin = A0;

/* =========================
 * Helpers internos
 * ========================= */

static const adc_range_cfg_t *find_range_cfg(adc_range_id_t r)
{
    for (unsigned i = 0; i < sizeof(adc_ranges) / sizeof(adc_ranges[0]); ++i)
    {
        if (adc_ranges[i].id == r)
            return &adc_ranges[i];
    }
    return nullptr;
}

static uint8_t channel_to_analog_pin(adc_channel_t ch)
{
    // En Arduino clásico: A0 + n
    switch (ch)
    {
    case ADC_CH_0:
        return A0;
    case ADC_CH_1:
        return A1;
    case ADC_CH_2:
        return A2;
    case ADC_CH_3:
        return A3;
    case ADC_CH_4:
        return A4;
    case ADC_CH_5:
        return A5;
#if defined(A6)
    case ADC_CH_6:
        return A6;
#endif
#if defined(A7)
    case ADC_CH_7:
        return A7;
#endif
    default:
        return A0;
    }
}

static void ads1115_write_config(uint16_t config)
{
    Wire.beginTransmission(ADS1115_ADDR);
    Wire.write(0x01); // Registro CONFIG
    Wire.write(config >> 8);
    Wire.write(config & 0xFF);
    Wire.endTransmission();
}

static uint16_t ads1115_read_conversion()
{
    Wire.beginTransmission(ADS1115_ADDR);
    Wire.write(0x00); // Registro de conversión
    Wire.endTransmission();

    Wire.requestFrom(ADS1115_ADDR, 2);
    uint16_t hi = Wire.read();
    uint16_t lo = Wire.read();

    return (hi << 8) | lo;
}

static void apply_reference(adc_reference_t ref)
{
    switch (ref)
    {
    case ADC_REF_AVCC:
        analogReference(DEFAULT); // AVCC
        break;
    case ADC_REF_INTERNAL_1V1:
#if defined(INTERNAL)
        analogReference(INTERNAL); // 1.1V interna (según MCU)
#endif
        break;
    case ADC_REF_EXTERNAL:
        analogReference(EXTERNAL); // AREF externa
        break;
    }
}

/* =========================
 * API pública
 * ========================= */

void adc_manager_init(void)
{
    // Referencia por defecto
    analogReference(DEFAULT);

    current_range = RANGE_NONE;
    current_analog_pin = A0;
}

void adc_manager_select(adc_range_id_t range)
{
    const adc_range_cfg_t *cfg = find_range_cfg(range);
    if (!cfg)
    {
        current_range = RANGE_NONE;
        return;
    }

    current_range = range;

    // --- MUX según canal ---
    uint16_t mux = 0;
    switch (cfg->ch)
    {
    case ADC_CH_0:
        mux = 0x4000;
        break; // AIN0
    case ADC_CH_1:
        mux = 0x5000;
        break; // AIN1
    case ADC_CH_2:
        mux = 0x6000;
        break; // AIN2
    case ADC_CH_3:
        mux = 0x7000;
        break; // AIN3
    }

    // --- PGA dinámico según rango ---
    switch (range)
    {
    case RANGE_DC_200mV:
        ads_gain = 0x0A00; // ±0.256V
        break;

    case RANGE_DC_2V:
        ads_gain = 0x0400; // ±2.048V
        break;

    case RANGE_CURR_20mA:
        ads_gain = 0x0800; // ±0.512V (máxima resolución para mA)
        break;

    case RANGE_DC_20V:
    case RANGE_DC_200V:
    case RANGE_OHM_100:
    case RANGE_OHM_10K:
    case RANGE_OHM_1M:
    case RANGE_CURR_200mA:
    case RANGE_CURR_16A:
    case RANGE_AC_2V:
    case RANGE_AC_20V:
    case RANGE_AC_200V:
    case RANGE_TRANSISTOR:
        ads_gain = 0x0200; // ±4.096V
        break;

    default:
        ads_gain = 0x0200;
        break;
    }

    // --- Construir registro CONFIG ---
    uint16_t config =
        ADS_OS_SINGLE |       // Start conversion
        mux |                 // Canal
        ads_gain |            // Ganancia
        ads_sps |             // SPS configurado
        ADS_MODE_SINGLE |     // Single-shot
        ADS_COMP_QUE_DISABLE; // Comparador desactivado

    // --- Enviar al ADS1115 ---
    ads1115_write_config(config);
}

uint16_t ads_mux = 0;
uint16_t ads_gain = 0;
uint16_t ads_sps = 0x00A0; // 250 SPS por defecto

bool adc_manager_read(uint16_t *value)
{
    if (!value)
        return false;

    // Implementación sencilla: lectura directa siempre "estable"
    int raw = analogRead(current_analog_pin);
    if (raw < 0)
        raw = 0;
    if (raw > 1023)
        raw = 1023;

    *value = (uint16_t)raw;
    return true;
}

uint16_t adc_manager_read_blocking(void)
{
    int raw = analogRead(current_analog_pin);
    if (raw < 0)
        raw = 0;
    if (raw > 1023)
        raw = 1023;
    return (uint16_t)raw;
}

adc_range_id_t adc_manager_current_range(void)
{
    return current_range;
}

float adc_manager_raw_to_voltage(uint16_t raw)
{
    int16_t s = (int16_t)raw;

    float lsb = 0.000125f; // default ±4.096V

    switch (ads_gain)
    {
    case 0x0A00:
        lsb = 0.0000078125f;
        break; // ±0.256V
    case 0x0800:
        lsb = 0.000015625f;
        break; // ±0.512V
    case 0x0600:
        lsb = 0.00003125f;
        break; // ±1.024V
    case 0x0400:
        lsb = 0.0000625f;
        break; // ±2.048V
    case 0x0200:
        lsb = 0.000125f;
        break; // ±4.096V
    case 0x0000:
        lsb = 0.0001875f;
        break; // ±6.144V
    }

    return s * lsb;
}

void adc_manager_set_sps(adc_sps_t sps)
{
    uint16_t config = 0;

    switch (sps)
    {
    case ADC_SPS_8:
        config = 0x0000;
        break;
    case ADC_SPS_16:
        config = 0x0020;
        break;
    case ADC_SPS_32:
        config = 0x0040;
        break;
    case ADC_SPS_64:
        config = 0x0060;
        break;
    case ADC_SPS_128:
        config = 0x0080;
        break;
    case ADC_SPS_250:
        config = 0x00A0;
        break;
    case ADC_SPS_475:
        config = 0x00C0;
        break;
    case ADC_SPS_860:
        config = 0x00E0;
        break;
    }

    // Guardar en la configuración interna del ADS1115
    ads_sps = config; // variable interna que ya usa adc_manager_select()
}
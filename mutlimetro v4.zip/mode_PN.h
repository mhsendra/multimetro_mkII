#ifndef MODE_PN_H
#define MODE_PN_H

#include <stdint.h>

// Dispatcher principal del modo PN (Diodo / Transistor / MOSFET / Zener)
void measurePN_MODE();

#endif
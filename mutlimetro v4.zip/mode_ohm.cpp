#include "mode_ohm.h"
#include "adcmanager.h"
#include "globals.h"
#include "lcd_ui.h"
#include "config.h"
#include "OhmMinMax.h"
#include "auto_Hold.h"
#include "backlight.h"
#include "AutoOff.h"
#include <math.h>
#include "range_control.h"

// =====================================================
// CONSTANTES DE CORRIENTE DE TEST (AJUSTABLES)
// =====================================================
#define I_TEST_200 0.001f    // ~1 mA   (rango 100 Ω)
#define I_TEST_2K 0.0001f    // ~0.1 mA (rango 10 kΩ)
#define I_TEST_2M 0.0000001f // ~0.1 µA (rango 1 MΩ)

// =====================================================
// MAPEO DE RANGO ADC → SÍMBOLO L / M / H
// =====================================================
static const char *getOhmRangeSymbol(adc_range_id_t range)
{
    switch (range)
    {
    case RANGE_OHM_100:
        return "L"; // 100 Ω
    case RANGE_OHM_10K:
        return "M"; // 10 kΩ
    case RANGE_OHM_1M:
        return "H"; // 1 MΩ
    default:
        return "?";
    }
}

// =====================================================
// AUTO‑RANGO SOBRE RANGOS ADC (RANGE_OHM_*)
// =====================================================
static adc_range_id_t ohm_autorange(float R, adc_range_id_t current)
{
    switch (current)
    {
    case RANGE_OHM_100:
        if (R > OHM_100_MAX)
            return RANGE_OHM_10K;
        break;

    case RANGE_OHM_10K:
        if (R > OHM_10K_MAX)
            return RANGE_OHM_1M;
        if (R < OHM_10K_MIN)
            return RANGE_OHM_100;
        break;

    case RANGE_OHM_1M:
        if (R < OHM_1M_MIN)
            return RANGE_OHM_10K;
        break;
    }

    return current;
}

// =====================================================
// CONTROL DE RELÉS OHM (74HC138 → CD4053B)
// =====================================================
static void ohm_set_relays(adc_range_id_t range)
{
    switch (range)
    {
    case RANGE_OHM_100: // 100 Ω
        digitalWrite(pin.RNG2, LOW);
        digitalWrite(pin.RNG1, LOW);
        digitalWrite(pin.RNG0, LOW);
        break;

    case RANGE_OHM_10K: // 10 kΩ
        digitalWrite(pin.RNG2, LOW);
        digitalWrite(pin.RNG1, LOW);
        digitalWrite(pin.RNG0, HIGH);
        break;

    case RANGE_OHM_1M: // 1 MΩ
        digitalWrite(pin.RNG2, LOW);
        digitalWrite(pin.RNG1, HIGH);
        digitalWrite(pin.RNG0, LOW);
        break;

    default:
        break;
    }
}

// =====================================================
// PROTECCIÓN OHM — DETECCIÓN DE TENSIÓN EXTERNA
// =====================================================
static float ohm_check_voltage()
{
    // Seleccionamos un rango de voltaje seguro
    adc_manager_select(RANGE_DC_20V);

    // Leer RAW del ADS1115
    uint16_t raw = adc_manager_read_blocking();

    // Convertir a voltios reales
    float v_adc = adc_manager_raw_to_voltage(raw);

    // Escalado del rango DC_20V (mismo factor que en VDC)
    float v = v_adc * 0.110f;

    return v;
}

static void showOHM_Protect()
{
    lcd_ui_clear();
    lcd_ui_print("OHM PROTECT");
}

// =====================================================
// OHM — RAW usando ADC Manager (corriente de test)
// =====================================================
static float measureOHM_raw()
{
    // Leer RAW del ADS1115 en el rango actual
    uint16_t raw = adc_manager_read_blocking();

    // Convertir a voltios reales
    float v_adc = adc_manager_raw_to_voltage(raw);

    // Protección por saturación del ADC
    if (fabs(v_adc) > 4.95f)
        return INFINITY;

    float R = NAN;

    switch (adc_manager_current_range())
    {
    case RANGE_OHM_100:
        R = v_adc / I_TEST_200; // Corriente de test para rango 100 Ω
        break;

    case RANGE_OHM_10K:
        R = v_adc / I_TEST_2K; // Corriente de test para rango 10 kΩ
        break;

    case RANGE_OHM_1M:
        R = v_adc / I_TEST_2M; // Corriente de test para rango 1 MΩ
        break;

    default:
        return NAN;
    }

    return R;
}

// =====================================================
// OHM — CALIBRADO
// =====================================================
static float measureOHM_calibrated()
{
    float R = measureOHM_raw();
    if (isinf(R))
        return R;

    return R * cal.ohm;
}

// =====================================================
// SUBMODO: CONTINUIDAD (con histéresis y beep estable)
// =====================================================
static void showContinuity(float R, adc_range_id_t range)
{
    static bool beepState = false;

    if (R < OHM_CONT_THRESHOLD - 2.0f)
        beepState = true;
    if (R > OHM_CONT_THRESHOLD + 2.0f)
        beepState = false;

    lcd_ui_clear();

    if (beepState)
    {
        lcd_ui_print("BEEP ");
        tone(pin.PIN_BUZZER, 4000);
    }
    else
    {
        lcd_ui_print("---- ");
        noTone(pin.PIN_BUZZER);
    }

    lcd_ui_print(getOhmRangeSymbol(range));
}

// =====================================================
// SUBMODO: RELATIVO
// =====================================================
static void showOhmRelative(float R, adc_range_id_t range)
{
    if (isnan(ohmRef))
        ohmRef = R;

    float diff = R - ohmRef;

    if (autoHold_update(diff))
        diff = autoHold_getHeldValue();

    lcd_ui_clear();
    lcd_ui_print("REL ");
    lcd_ui_printFloat(diff, 1);
    lcd_ui_print(" ");
    lcd_ui_print(getOhmRangeSymbol(range));
}

// =====================================================
// SUBMODO: MIN / MAX
// =====================================================
static void showOhmMinMax(adc_range_id_t range)
{
    lcd_ui_clear();
    ohmMinMax_show();
    lcd_ui_print(" ");
    lcd_ui_print(getOhmRangeSymbol(range));
}

// =====================================================
// SUBMODO: TEST DE CABLES
// =====================================================
static void showCableTest(float R, adc_range_id_t range)
{
    lcd_ui_clear();

    if (R < 2.0f)
        lcd_ui_print("CABLE OK ");
    else
        lcd_ui_print("NO CABLE ");

    lcd_ui_print(getOhmRangeSymbol(range));
}

// =====================================================
// SUBMODO: PRINCIPAL OHM
// =====================================================
static void showOhmMain(float R, adc_range_id_t range)
{
    if (autoHold_update(R))
        R = autoHold_getHeldValue();

    lcd_ui_clear();
    lcd_ui_printFloat(R, 1);
    lcd_ui_print(" Ohm ");
    lcd_ui_print(getOhmRangeSymbol(range));
}

// =====================================================
// MODO COMPLETO OHM (dispatcher con submodos)
// =====================================================
void measureOHM_MODE()
{
    // Restaura los pines RNGx para el modo OHM
    rng_restore_for_ohm();

    // Velocidad adecuada del ADS1115 para OHM
    adc_manager_set_sps(ADC_SPS_475);

    // 1. Protección OHM (no medir si hay tensión externa)
    float v_ext = ohm_check_voltage();
    if (v_ext > OHM_PROTECT_THRESHOLD)
    {
        showOHM_Protect();
        return;
    }

    // 2. Rango actual persistente (ADC)
    static adc_range_id_t range = RANGE_OHM_10K;

    // 3. Activar relés según rango
    ohm_set_relays(range);

    // 4. Seleccionar rango en ADC Manager
    adc_manager_select(range);

    // 5. Medición calibrada
    float R = measureOHM_calibrated();

    // 6. Auto‑rango (solo si la lectura es válida)
    if (!isinf(R) && !isnan(R))
    {
        adc_range_id_t newRange = ohm_autorange(R, range);
        if (newRange != range)
        {
            range = newRange;
            backlight_activity();
            autoOff_activity();
            return; // siguiente ciclo medirá con el nuevo rango
        }
    }

    // 7. Actividad de usuario si lectura válida
    if (!isinf(R) && !isnan(R))
    {
        backlight_activity();
        autoOff_activity();
    }

    // 8. Dispatcher de submodos
    switch (ohmSubMode)
    {
    case OHM_MAIN:
        showOhmMain(R, range);
        break;

    case OHM_CONT:
    {
        bool beep = (R < OHM_CONT_THRESHOLD - 2.0f);
        if (beep)
        {
            backlight_activity();
            autoOff_activity();
        }
        showContinuity(R, range);
    }
    break;

    case OHM_REL:
        showOhmRelative(R, range);
        break;

    case OHM_MINMAX:
        if (!isinf(R) && !isnan(R))
            ohmMinMax_update(R);
        showOhmMinMax(range);
        break;

    case OHM_CABLE:
        showCableTest(R, range);
        break;
    }
}

// Alias opcional si en algún sitio se llama aún measureOHM()
void measureOHM()
{
    measureOHM_MODE();
}
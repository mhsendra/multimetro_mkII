#ifndef OHM_MINMAX_H
#define OHM_MINMAX_H

void ohmMinMax_reset();
void ohmMinMax_update(float R);
void ohmMinMax_show();

#endif